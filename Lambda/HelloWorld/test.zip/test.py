
def lambda_handler(event, context):
    name = "trikr"
    print(name)